
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/notify-turn.mjs
var BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
var DB_URL = "https://qwirkle-online-6ca1c-default-rtdb.europe-west1.firebasedatabase.app";
var notify_turn_default = async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  try {
    const { playerId, roomCode, gameName } = await req.json();
    if (!playerId || !roomCode) {
      return new Response(JSON.stringify({ error: "Missing playerId or roomCode" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const res = await fetch(`${DB_URL}/profiles/${playerId}.json`);
    const profile = await res.json();
    if (!profile?.telegramChatId || !profile?.telegramNotifications) {
      return new Response(JSON.stringify({ skipped: true }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
    if (profile.telegramMutedGames?.[roomCode]) {
      return new Response(JSON.stringify({ skipped: true, reason: "muted" }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
    const displayName = gameName || "Qwirkle";
    const siteUrl = "https://qwirkle.ewakon.pl";
    const tgRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: profile.telegramChatId,
        text: `\u{1F3B2} <b>Tw\xF3j ruch!</b> / <b>Your turn!</b>
${displayName}`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[
            { text: "\u25B6\uFE0F Zagraj / Play", url: siteUrl }
          ]]
        }
      })
    });
    const tgResult = await tgRes.json();
    return new Response(JSON.stringify({ sent: tgResult.ok }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = {
  path: "/api/notify-turn"
};
export {
  config,
  notify_turn_default as default
};
