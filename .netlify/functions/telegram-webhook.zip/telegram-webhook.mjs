
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/telegram-webhook.mjs
var BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
var DB_URL = "https://qwirkle-online-6ca1c-default-rtdb.europe-west1.firebasedatabase.app";
async function sendTelegram(chatId, text) {
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" })
  });
}
async function dbGet(path) {
  const res = await fetch(`${DB_URL}/${path}.json`);
  return res.json();
}
async function dbPatch(path, data) {
  await fetch(`${DB_URL}/${path}.json`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
}
var telegram_webhook_default = async (req) => {
  if (req.method !== "POST") return new Response("OK", { status: 200 });
  const update = await req.json();
  const message = update?.message;
  if (!message?.text) return new Response("OK", { status: 200 });
  const chatId = message.chat.id;
  const text = message.text.trim();
  if (text.startsWith("/start")) {
    const parts = text.split(" ");
    const uid = parts[1];
    if (!uid) {
      await sendTelegram(
        chatId,
        "\u26A0\uFE0F U\u017Cyj linku z aplikacji Qwirkle, aby po\u0142\u0105czy\u0107 konto.\n\u26A0\uFE0F Use the link from the Qwirkle app to connect your account."
      );
      return new Response("OK", { status: 200 });
    }
    const profile = await dbGet(`profiles/${uid}`);
    if (!profile) {
      await sendTelegram(
        chatId,
        "\u274C Nie znaleziono konta. Spr\xF3buj ponownie z aplikacji.\n\u274C Account not found. Try again from the app."
      );
      return new Response("OK", { status: 200 });
    }
    await dbPatch(`profiles/${uid}`, {
      telegramChatId: chatId,
      telegramNotifications: true
    });
    const nickname = profile.nickname || "Gracz";
    await sendTelegram(
      chatId,
      `\u2705 Po\u0142\u0105czono z kontem <b>${nickname}</b>!
B\u0119dziesz dostawa\u0107 powiadomienia gdy nadejdzie Tw\xF3j ruch.

\u2705 Connected to <b>${nickname}</b>!
You'll receive notifications when it's your turn.`
    );
    return new Response("OK", { status: 200 });
  }
  if (text === "/stop") {
    const profiles = await dbGet("profiles");
    if (profiles) {
      for (const [uid, p] of Object.entries(profiles)) {
        if (p && p.telegramChatId === chatId) {
          await dbPatch(`profiles/${uid}`, { telegramNotifications: false });
        }
      }
    }
    await sendTelegram(
      chatId,
      "\u{1F515} Powiadomienia wy\u0142\u0105czone. Wpisz /on aby w\u0142\u0105czy\u0107 ponownie.\n\u{1F515} Notifications disabled. Type /on to re-enable."
    );
    return new Response("OK", { status: 200 });
  }
  if (text === "/on") {
    const profiles = await dbGet("profiles");
    if (profiles) {
      for (const [uid, p] of Object.entries(profiles)) {
        if (p && p.telegramChatId === chatId) {
          await dbPatch(`profiles/${uid}`, { telegramNotifications: true });
        }
      }
    }
    await sendTelegram(
      chatId,
      "\u{1F514} Powiadomienia w\u0142\u0105czone!\n\u{1F514} Notifications enabled!"
    );
    return new Response("OK", { status: 200 });
  }
  await sendTelegram(
    chatId,
    "\u{1F3B2} Qwirkle Bot\n\n/stop \u2014 wy\u0142\u0105cz powiadomienia / disable notifications\n/on \u2014 w\u0142\u0105cz powiadomienia / enable notifications"
  );
  return new Response("OK", { status: 200 });
};
var config = {
  path: "/api/telegram-webhook"
};
export {
  config,
  telegram_webhook_default as default
};
